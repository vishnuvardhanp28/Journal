# Image encryption demonstration files

## Open the pictures

- `4.1.07.tiff` and `4.1.08.tiff` are the original color images.
- `ciphertext_views/*_ciphertext_bytes.png` are display previews of encrypted bytes, reshaped as RGB. They are not the encrypted files and cannot be decrypted.
- `decrypted/*_decrypted.png` are normal viewable PNGs recovered from the encrypted files and checked pixel-for-pixel against the originals.
- `color_original_ciphertext_decrypted_histograms.png` is the paper figure: for each image, the original, ciphertext preview, and decrypted image are side by side, with each RGB histogram directly below its image.

## Grayscale examples

`grayscale_demo/figures/grayscale_original_ciphertext_decrypted_histograms.png` provides the same three-column image comparison and histograms for two grayscale conversions. The grayscale `.imgenc` files, viewable byte previews, exact decrypted PNGs, and exposed demo-only keys are in the matching subfolders. These are illustrations for the AES-GCM control, not tests of the six custom ciphers.

## Actual encrypted files

The real encrypted outputs are in `encrypted/*.imgenc`. They are binary AES-256-GCM containers, so a photo viewer will not display them. Each has a matching key in `demo_keys/*_DEMO_ONLY.key.txt`. The keys are deliberately included for this demonstration; these sample files are not confidential and the keys must never be reused for private data.

## Results and scope

`expanded_security_demo.json`, `attack_diagnostics.csv`, `timing_attack_probe.csv`, and `file_timing.csv` contain the measurements. `RESULTS_README.md` summarizes entropy, histograms, spatial correlation, NPCR/UACI, noise and integrity probes, CPA/KPA/COA diagnostics, timing, key sensitivity, brute-force scope, and time/space complexity. These tests evaluate AES-GCM and ChaCha20-Poly1305 reference controls. They do not evaluate the six custom ciphers in the supplied papers.

The outputs use USC-SIPI images 4.1.07 and 4.1.08. Source/output hashes are recorded in `visual_manifest.json`.
