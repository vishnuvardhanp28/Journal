"""Build the four-example original/ciphertext-preview/decryption panel."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'manuscript'/'figures'/'image_comparison_montage.png'
rows=[
 ('Grayscale','4.1.07',ROOT/'results/grayscale_demo/original/4.1.07_grayscale.png',ROOT/'results/grayscale_demo/ciphertext_views/4.1.07_AES-256-GCM_ciphertext_bytes.png',ROOT/'results/grayscale_demo/decrypted/4.1.07_AES-256-GCM_decrypted.png'),
 ('Grayscale','4.1.08',ROOT/'results/grayscale_demo/original/4.1.08_grayscale.png',ROOT/'results/grayscale_demo/ciphertext_views/4.1.08_AES-256-GCM_ciphertext_bytes.png',ROOT/'results/grayscale_demo/decrypted/4.1.08_AES-256-GCM_decrypted.png'),
 ('Color','4.1.07',ROOT/'results/expanded_color_demo/original/4.1.07.tiff',ROOT/'results/expanded_color_demo/ciphertext_views/4.1.07_aes_gcm_ciphertext_bytes.png',ROOT/'results/expanded_color_demo/decrypted/4.1.07_AES-256-GCM_decrypted.png'),
 ('Color','4.1.08',ROOT/'results/expanded_color_demo/original/4.1.08.tiff',ROOT/'results/expanded_color_demo/ciphertext_views/4.1.08_aes_gcm_ciphertext_bytes.png',ROOT/'results/expanded_color_demo/decrypted/4.1.08_AES-256-GCM_decrypted.png')]
W,H=1900,1160; left=185; gap=34; cell=510; top=120; rowh=245
canvas=Image.new('RGB',(W,H),'white'); d=ImageDraw.Draw(canvas)
fontdir=Path('C:/Windows/Fonts')
def font(name,size):
 q=fontdir/name; return ImageFont.truetype(str(q),size) if q.exists() else ImageFont.load_default()
title=font('arialbd.ttf',34); head=font('arialbd.ttf',25); label=font('arial.ttf',21); small=font('arial.ttf',19)
d.text((W/2,28),'Original, ciphertext-byte preview, and exact decryption',fill='#173c5e',font=title,anchor='mt')
xs=[left,left+cell+gap,left+2*(cell+gap)]
for x,name in zip(xs,['Original image','Ciphertext-byte preview','Decrypted image']): d.text((x+cell/2,85),name,fill='#25384b',font=head,anchor='mm')
for i,(mode,ident,*paths) in enumerate(rows):
 y=top+i*rowh
 if i==2:d.line((25,y-14,W-25,y-14),fill='#274f72',width=3)
 d.multiline_text((25,y+rowh/2),f'{mode}\n{ident}',fill='#273b4f',font=label,anchor='lm',spacing=8)
 for x,path in zip(xs,paths):
  with Image.open(path) as im:
   im=im.convert('RGB'); im.thumbnail((cell-12,rowh-22),Image.Resampling.LANCZOS); frame=Image.new('RGB',(cell-12,rowh-22),'white'); frame.paste(im,((frame.width-im.width)//2,(frame.height-im.height)//2))
  canvas.paste(frame,(x+6,y+4)); d.rectangle((x+5,y+3,x+cell-6,y+rowh-18),outline='#9aa8b4',width=1)
d.text((W/2,H-32),'The encrypted file is binary; the middle panels reshape ciphertext-body bytes for display only.',fill='#444444',font=small,anchor='ms')
OUT.parent.mkdir(parents=True,exist_ok=True); canvas.save(OUT,optimize=True); print(OUT)
