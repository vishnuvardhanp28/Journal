# Venue assessment for the image-encryption study

**Date checked:** 2026-10-25  
**Recommended conditional target:** IEEE Transactions on Information Forensics and Security (T-IFS)

## Evidence from Vishnu's IEEE title list

The supplied `Pasted text.txt` lists these relevant Q1 journals:

| Journal | Row | Quartile in supplied list | JIF in supplied list | Fit to the current study |
|---|---:|---|---:|---|
| IEEE Transactions on Information Forensics and Security (T-IFS) | 164 | Q1 | 8.7 | Best conditional fit if the work contributes substantive security analysis or cryptanalysis with reproducible evidence. |
| IEEE Transactions on Dependable and Secure Computing (T-DSC) | 140 | Q1 | 6.8 | Possible if reframed around a concrete secure-system dependability problem and its evaluation. |
| IEEE Transactions on Image Processing (T-IP) | 159 | Q1 | 15.3 | Would require a substantial image-processing contribution; image-encryption metrics alone are a weak fit. |

These quartiles and metrics are transcribed from the user-provided list; they are not independently recalculated.

## Current official scope and submission guidance

T-IFS's official scope includes information security and its site encourages reproducible research by publishing information needed to reproduce figures and tables. The IEEE Signal Processing Society author information requires a clear problem and contribution, significance, related-work context, novelty, suitable scope, and sufficient experimental evidence. Its current initial regular-paper limit is 13 double-column pages at 10-point type. It also requires ORCID for each author.

- [T-IFS scope and reproducible-research guidance](https://signalprocessingsociety.org/publications-resources/ieee-transactions-information-forensics-and-security/about-transactions)
- [IEEE Signal Processing Society information for authors](https://signalprocessingsociety.org/publications-resources/information-authors)
- [IEEE T-DSC scope](https://www.computer.org/digital-library/journals/tq/cfp-dependable-secure-computing)

## Recommendation and current gaps

Keep T-IFS as a **conditional target**, not a promised destination. It aligns better than the other listed Q1 candidates with a security contribution. The new Zhang et al. equation audit adds a scheme-specific collision/correctness result and materially strengthens the draft. However, no full custom cipher among the six has been reproduced end to end, including no full chaotic or quantum implementation; broader significance and experimental sufficiency still need validation. Source rights, a persistent code/data deposit, final author details, ORCIDs, and compiled page count also remain to be completed. A Q1 ranking or template cannot guarantee acceptance. Reassess the venue after an independent end-to-end implementation or a fully justified security proof and compilation against current author instructions.
